 /* 
 Real Time Embedded Systems-CSE522
 Team 10
 Shubham Nandanwankar 1213350370
 Achal Shah 		  1213294158


 We have referred the sample codes given provided by zephyr also in the zephyr kernel primer documentation.


 */

#include <zephyr.h>
#include <misc/printk.h>
#include <board.h>
#include <device.h>
#include <gpio.h>
#include <asm_inline_gcc.h>
#include <misc/util.h>
#include <pwm.h>
#include <pinmux.h>
#include <kernel.h>
#include <shell/shell.h>
#include <stdio.h>
#include <stdlib.h>


#define PWM0 CONFIG_PWM_PCA9685_0_DEV_NAME	//pwm driver name
#define GPIO CONFIG_GPIO_DW_0_NAME			// GPIO driver name
#define MUX CONFIG_PINMUX_NAME 				// pinmux driver name
#define PULL_UP 0							// pull up value
#define EDGE    (GPIO_INT_EDGE | GPIO_INT_ACTIVE_HIGH) // Rising edge confuguration macros
#define MY_SHELL_MODULE "Team_10_shell"		//Shell module name can be selected using "select" command				
#define MY_STACK_SIZE 500					//stack size definition
#define MY_PRIORITY 5						//Higher priority thread priority for context switch overhead
#define MY_PRIORITY1 8						//Lower priority thread priority for context switch overhead

extern void my_entry_point(void* , void *, void *); //Lower priority thread entry function for context switch overhead
extern void my_entry_point1(void* , void *, void *); //High priority thread entry function for context switch overhead


// u32_t start_time;
long long start_time,mutex_start_time; // start time variable for calculation of latency and mutex locking & unlocking time
// u32_t stop_time;
long long stop_time,mutex_stop_time; // stop time variable for calculation of latency and mutex locking & unlocking time
// u32_t diff;
long long diff;
int cnt = 1;
int count=0;
char array_flag,term_flag;


K_THREAD_STACK_DEFINE(my_stack_area, MY_STACK_SIZE);	// stack area definition for all the thread
K_THREAD_STACK_DEFINE(my_stack_area1, MY_STACK_SIZE);
K_THREAD_STACK_DEFINE(pwm_stack_area, MY_STACK_SIZE);
K_THREAD_STACK_DEFINE(msg_q_stack_thread1, MY_STACK_SIZE);
K_THREAD_STACK_DEFINE(msg_q_stack_thread2, MY_STACK_SIZE);
struct k_thread my_thread_data, my_thread_data1,msg_q_thread1,msg_q_thread2; // thread creation
struct k_mutex my_mutex; // mutex creation


int int_back[500],int_wo_back[500],cont_swt[500]; //buffer to store different latencies
char msg_data[12]="thread 1";	// message to be passed in message queue

static struct gpio_callback callb;	// callback object 
struct device *dev1;				// device pointer to set gpios
struct device *dev2;
struct device *dev3;
struct device *dev4;
struct device *dev5;
struct device *dev6;



struct data_item_type {		// struct for message size
  char msg[12];
};

struct data_item_type data;	
char __aligned(4) my_msgq_buffer[10 * sizeof(data)];// aligning of the message as per the power of 2 
struct k_msgq my_msgq;	//Message queue object creation

void my_entry_point(void* a ,void* b,void* c){ 		// Low priority thread to calculate context switch overhead
	while(count <500){
		// printk("Mutex locked for thread 1\n");
		if(k_mutex_lock(&my_mutex, K_FOREVER)!=0)	// locking the resource so that higher priority thread will not preempt it unless unlocked
			printk("Mutex error tthread 1\n");
		 // while(1){
			long long i=0;
			// printk("The thread is 1:%d\n",k_current_get());
			k_sleep(20);

			while(i<INT_MAX/10){
				i++;
			}
			
		start_time=_tsc_read();		// start of tsc timstamp to compute context switch overhead
		// printk("RDTSC count start1:%llu\n",cont_swt_start);	
		k_mutex_unlock(&my_mutex); // context switch will occur as soon as this thread is unlocked
		// printk("Mutex unlocked for thread 1\n");
		
	}
	
}

void my_entry_point1(void* a ,void* b,void* c){	// High priority thread to calculate context switch overhead
	

	  while(count<500){
			long i=0;
			// printk("The thread is 2:%d\n",k_current_get());
			k_sleep(2);
			// printk("The thread is 2 sleep bahar \n");
			if(k_mutex_lock(&my_mutex, K_FOREVER)!=0)	// higher priority thread will be blocked 
				printk("Mutex error tthread 1\n");
			stop_time=_tsc_read();	//// start of tsc timstamp to compute context switch overhead

			// printk("RDTSC count start2:%llu\n",cont_swt_end);
			
			// printk("Mutex locked for thread 2\n");
			while(i<INT_MAX/100){
				i++;
			}	

			k_mutex_unlock(&my_mutex);
			// printk("Context switch overhead:%llu\n",stop_time-start_time);
			cont_swt[count]=stop_time-start_time-mutex_stop_time; // context switch time calculation subtracting mutex unlocking 
			stop_time=start_time=0;
			count++;
	 }

term_flag='e'; // termination flag


}


void gpio_set(void);	// function to step gpios
// void pwm_gen(void* a,void* b,void* c);
void msg_q_1(void* a,void* b,void* c); // thread to calculate interrupt latency with backgroung task
void msg_q_2(void* a,void* b,void* c);	// thread to calculate interrupt latency with backgroung task

void handler(struct device *dev6, struct gpio_callback *callb, u32_t pin){	// Callback interrupt handler
	stop_time=_tsc_read();
	diff=stop_time-start_time;
	if(array_flag=='a'){
		// printk("\n Latency W/O background task %lld\n",diff);
		int_wo_back[count]=diff;			// calculates latency and stores it in the buffer for without any background task
	}
	else if(array_flag=='b'){
		// printk("\n latency with background tasks %lld\n",diff);
		int_back[count]=diff;				// calculates latency and stores it in the buffer for with background task
	}
	count+=1;

}
static int shell_cmd_arrayprint(int argc, char *argv[]){	// function to implement shell command

	printk("Printing time in nanoseconnds\n");
	printk("Cntx Swt\tInt W/O Back\t Int With Back\n");
	for(int i=0;i<atoi(argv[1]);i++){
		
		printk("%d\t\t%d\t\t%d\n",cont_swt[i],int_wo_back[i],int_back[i]);
	}
	return 0;
}

static struct shell_cmd commands[] = {		// command data structure
	{ "arrayprint",shell_cmd_arrayprint,"Prints array" },
	{NULL,NULL,NULL}
};



void main(void)
{
	
	gpio_set();							// setting gpio
	struct device *pwm_dev;				// device pointer for pwm binding
	struct device *pinmux;				// device pointer for pinmux binding
	pwm_dev = device_get_binding(PWM0);	// Binding pwm driver to the pointer
	pinmux = device_get_binding(MUX);	// Binding pwm driver to the pointer
	pinmux_pin_set(pinmux, 5, PINMUX_FUNC_C);// Setting pin IO 5 for pwm configuration
	gpio_init_callback(&callb,handler, BIT(3));// intializing callback on the IO0
	gpio_add_callback(dev6, &callb);	//binding call back with device pointer

	for(int i=1;i<=3;i++){
			switch(i){

			case 1:	// calculation for context switch overhead
					printk("****************Context Switch Overhead******************\n");
					// printk("");
					k_mutex_init(&my_mutex);
					mutex_start_time=_tsc_read();
					k_mutex_lock(&my_mutex, K_FOREVER);	// Calculating mutex lock time
					mutex_stop_time=_tsc_read();

					printk("Mutex lock time%lld\n",mutex_stop_time-mutex_start_time);

					mutex_start_time=_tsc_read();
					k_mutex_unlock(&my_mutex);
					mutex_stop_time=_tsc_read();	// calculating mutex unlock time
					mutex_stop_time=mutex_stop_time-mutex_start_time;
					printk("Mutex unlock time%lld\n",mutex_stop_time);

					k_tid_t my_tid1 = k_thread_create(&my_thread_data1, my_stack_area1,			// lower priority thread creation 
				                             K_THREAD_STACK_SIZEOF(my_stack_area1),
				                             my_entry_point1,
				                             NULL, NULL, NULL,
				                             MY_PRIORITY1, 0, K_NO_WAIT);
					printk("Thread 2 with threadid:%d\n",(int)my_tid1);
					k_tid_t my_tid = k_thread_create(&my_thread_data, my_stack_area,			// High priority thread creation 
				                                 K_THREAD_STACK_SIZEOF(my_stack_area),
				                                 my_entry_point,	
				                                 NULL, NULL, NULL,
				                                 MY_PRIORITY, 0, K_NO_WAIT);
					printk("Thread 1 with threadid:%d\n",(int)my_tid);
					
					while(term_flag!='e'){

						k_sleep(50);			// safe termination condition, note that main will wait until all the computation is completed
					}

					break;

			case 2:	// calcul cyclesation for interrupt latency without any background tasks
					printk("****************Interrupt Latency without Background Computing******************\n");
					array_flag='a';
					gpio_pin_enable_callback(dev6,3);	// enabling interrupt handler
					pwm_pin_set_cycles(pwm_dev,3,4095,1000);// setting pwm on pin 0

					while(1){
						start_time=_tsc_read();			// continuosly reading time stamp so that when interrupt occurs start_time will serve as base for interrrupt latency calulation
						if(count==500)
							break;

					}
					gpio_pin_disable_callback(dev6,3);	// after five hundred readings handler will be disabled

					k_sleep(1000);

					break;

			case 3:	// calcul cyclesation for interrupt latency with background tasks
					printk("****************Interrupt Latency with Background Computing******************\n");
					array_flag='b';	
					pwm_pin_set_cycles(pwm_dev,3,4095,1000);
					k_msgq_init(&my_msgq, my_msgq_buffer, sizeof(data),5);//Initializing message queue with size five and aligned message size 
					k_tid_t msgq_1_tid = k_thread_create(&msg_q_thread1,msg_q_stack_thread1,	// thread creation of the thread which puts message in the message queue
				                                 K_THREAD_STACK_SIZEOF(msg_q_stack_thread1),msg_q_1,
				                                 NULL, NULL, NULL,
				                                 -1, 0, K_NO_WAIT);
					k_tid_t msgq_2_tid = k_thread_create(&msg_q_thread2,msg_q_stack_thread2,	// thread creation of the thread which gets message from the message queue
				                                 K_THREAD_STACK_SIZEOF(msg_q_stack_thread2),
				                                 msg_q_2,
				                                 NULL, NULL, NULL,
				                                 -1, 0, K_NO_WAIT);

					printk("In main %d %d\n",(int)msgq_1_tid,(int)msgq_2_tid);


					break;

			default:
					printk("Default Case !!\n");
					break;

		}
		count=0;

	 }

for(int i=0;i<500;i++){				// Calculating time in nanosecond in buffer
	cont_swt[i]=(cont_swt[i]*10)/4;					
	int_wo_back[i]=(int_wo_back[i]*10)/4;
	int_back[i]=(int_back[i]*10)/4;
	// printk("%d\n",cont_swt[i]);
}



printk("Computation is done, press enter for shell module \n");
SHELL_REGISTER(MY_SHELL_MODULE, commands);	// Registering shell module 

}

void msg_q_1(void* a ,void* b,void* c){	// 

	gpio_pin_enable_callback(dev6,3);
	while(1){
		
		
		start_time = _tsc_read();	//base time for interrrupt latency calculation
		k_msgq_put(&my_msgq, msg_data, K_FOREVER);	//Putting message in the message queue
		start_time = _tsc_read();	//base time for interrrupt latency calculation
		if(count==500){
			gpio_pin_disable_callback(dev6,3);	//disabling callback
			break;
		}
		
	}

}

void msg_q_2(void* a ,void* b,void* c){

	while(1){
		char data_received[12];
		start_time = _tsc_read();//base time for interrrupt latency calculation
		k_msgq_get(&my_msgq,data_received, K_FOREVER);//Getting message in the message queue
		start_time = _tsc_read();//base time for interrrupt latency calculation
		if(count==500){
			gpio_pin_disable_callback(dev6,3);//disabling callback
			break;
		}

	}
}

void gpio_set(){	// GPIO set up function IO0 for input to detect rising edge and IO1 as an output
	int flag;
	printk("Inside gpio set\n");

	dev1 = device_get_binding("EXP0");
	if(dev1==NULL)
		printk("Returning null 1");
	flag=gpio_pin_configure(dev1,12,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 1");
	flag=gpio_pin_write(dev1,12,0);
	if(flag<0)
		printk("Error in gpio_pin_write 1");



	dev2 = device_get_binding("EXP1");
	if(dev2==NULL)
		printk("Returning null 2");
	flag=gpio_pin_configure(dev2,13,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 2");
	flag=gpio_pin_write(dev2,13,0);
	if(flag<0)
		printk("Error in gpio_pin_write 2");


		
	dev3 = device_get_binding("GPIO_0");
	if(dev3==NULL)
		printk("Returning null 3");
	flag=gpio_pin_configure(dev3,4, GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 3");
	flag=gpio_pin_write(dev3,4,0); 
	if(flag<0)
		printk("Error in gpio_pin_write 3");


	dev4 = device_get_binding("EXP1");
	if(dev4==NULL)
		printk("Returning null 4");
	flag=gpio_pin_configure(dev4,0,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 4");
	flag=gpio_pin_write(dev4,0,1);
	if(flag<0)
		printk("Error in gpio_pin_write 4");



	dev5 = device_get_binding("EXP1");
	if(dev5==NULL)
		printk("Returning null 5");
	flag=gpio_pin_configure(dev5,1,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 5");
	flag=gpio_pin_write(dev5,1,0);
	if(flag<0)
		printk("Error in gpio_pin_write 5");

		
	dev6 = device_get_binding("GPIO_0");
	if(dev6==NULL)
		printk("Returning null 6");
	flag=gpio_pin_configure(dev6,3,GPIO_DIR_IN | GPIO_INT | EDGE);
	if(flag<0)
		printk("Error in gpio_pin_configure 6");
	if(flag<0)
		printk("Error in gpio_pin_write 6");
	printk("gpio_set end\n");



}

