CSE522 Team 10
Shubham Nandanwankar 1213350370
Achal Shah 	     1213294158 

Readme file to run main.c, $ZEPHYR_HOME is enviornment variable for your zephyr directory


1. Extract measure_10.zip file to $ZEPHYR_HOME/samples/ directory
2. Go into the directory using "cd $ZEPHYR_HOME/samples/measure_10" directory
3. make build directory here using "mkdir build" command
4. Check version of your cmake using "cmake --version" if it is 3.8 or above then go to step 6 else perform step 5 as well
5. Execute a command "source $ZEPHYR_HOME/zephyr-env.sh" this will update our cmake version
6. cmake using "cmake -DBOARD=galileo .."
7. Execute command "make", this command will generate multiple file as well as directory into your $ZEPHYR_HOME/samples/measure_10/build directory
8. Goto directory $ZEPHYR_HOME/samples/measure_10/build/zephyr
9. Copy zephyr.strip file into the /kernel directory of your sd card
10.Connect a male to male jumper wire from pin IO5(pwm output) to IO0(input)
11.Connect to the console using "putty" or "sudo screen /dev/ttyUSB0 115200"  
12.Reset Galileo board
13.You will see program executing, program will execute for 10-15 secs so wait until then you will be able to see the progress as it executes.
14. After you see "Computation is done, press enter for shell module" prompt displayed on the console press "enter" key
15. This will start shell console, there will be two shell packages 1.Team_10_shell 2.kernel. Using "help" command you will be able to see those
16. Go to "Team_10_shell" package using "select Team_10_shell" command, then type "help" to see what all commands are there.
17. There will be a command "arrayprint" which prints the buffere values computed for different latencies, type "arrayprint 10" where the preceding no. signifies how many data points you want to display
18. After executing the above instruction you will be able to see the all the 3 Buffer values.
