#include <device.h>
#include <zephyr/types.h>
#include <stdlib.h>
#include <kernel.h>
#include <string.h>
#include <board.h>
#include <sensor.h>
#include <gpio.h>
#include <errno.h>
#include<pinmux.h>
#include <misc/byteorder.h>
#include <misc/__assert.h>
#include <asm_inline_gcc.h>


#include "hcsr04.h"

struct device *dev_gpio;  //Device pointer to bind the GPIOs
struct device *pinmux;    //Device pointer to bind pinmux
struct sensor_value result; //Object of sensor value struct

long long start=0,stop=0,diff=0; //storing values of time stamps
u32_t stop_data_log;  


void handler(struct device *dev_gpio, struct gpio_callback *callb, u32_t pin)    // GPIO callback handler
{	
	long long tmp = _tsc_read();
	int v;  
	int f=0;
	gpio_pin_read(dev_gpio,5,&v);  // Reading the value of the edge pin to check the rising and falling edge
	
		if(v==1)   // Rising edge
		{
			start = tmp;
			gpio_pin_configure(dev_gpio,5,(GPIO_DIR_IN|GPIO_INT|GPIO_INT_EDGE | GPIO_INT_ACTIVE_LOW));  // Reconfiguring gpio pin to interrupt trigger for falling edge
		}
	

		else if(v == 0) // Falling edge
		{
			stop = tmp;
			gpio_pin_configure(dev_gpio,5,(GPIO_DIR_IN|GPIO_INT|GPIO_INT_EDGE | GPIO_INT_ACTIVE_HIGH));  // Reconfiguring gpio pin to interrupt trigger for rising edge
			f=1;
		}

		if(f)
		{
			diff = stop-start;         //Getting the difference of falling and rising edge 
			result.val1=(diff/(400*58));  //Using the difference to get the distance value in centimeters
			printk("The difference is %lld\n And the distance is = %u\n\n\n",diff, result.val1);
			
		}

	
}


static int hcsr_sample_fetch(struct device *dev, enum sensor_channel chan)  //Sensor sample_fetch API
{
	int flag;

	// printk("In the sample_fetch....\n");

	flag=gpio_pin_write(dev_gpio,4,1); 				//Giving trigger to the sensor
	if(flag<0)
		printk("Error in writing 1 ");

	k_busy_wait(75);
	flag=gpio_pin_write(dev_gpio,4,0); 
	if(flag<0)
		printk("Error in writing 0");
	k_busy_wait(500);
	
	return 0;
}

static int hcsr_channel_get(struct device *dev,			//Sensor channel_get API
			       enum sensor_channel chan,
			       struct sensor_value *val)
{
	
	val->val1 = result.val1;							//Storing the distance value in the val1 variable of the sensor_value struct
	val->val2=k_cycle_get_32();							//Storing the timestamp value in the val2 variable of the sensor_value struct
	return 0;
}

static const struct sensor_driver_api hcsr_driver_api = {  //Definig the sensor driver APIs
	.sample_fetch = hcsr_sample_fetch,
	.channel_get = hcsr_channel_get,
};



static int hcsr_init(struct device *dev){				// Sensor init

	printk("In the init function of device %s\n", dev->config->name);
	struct hcsr_data *drv_data = dev->driver_data;
	pinmux = device_get_binding(CONFIG_PINMUX_NAME);	//Binding the pinmux device with it's driver
		
	dev_gpio = device_get_binding("GPIO_0");			//Binding the GPIO device with it's driver

	drv_data->function = handler;						
	dev->driver_api = &hcsr_driver_api;					//Linking the defined APIs with device created 

	return 0;

}

struct hcsr_data hcsr_driver_0, hcsr_driver_1;			//objects of hcsr_data

DEVICE_INIT(HCSR0, CONFIG_HCSR_NAME_0, hcsr_init,			//Creating device instance HCSR0
		    &hcsr_driver_0, NULL,
		    POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY);

DEVICE_INIT(HCSR1, CONFIG_HCSR_NAME, hcsr_init,				//Creating device instance HCSR1
		    &hcsr_driver_1, NULL,
		    POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY);