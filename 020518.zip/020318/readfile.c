/* 

Real Time Embedded Systems CSE522

Assignment 1 

Assignment Objectives:
1. To program real-time tasks on Linux environment, including periodic and aporadic tasks, event handling,	
priority inheritance, etc.
2. To use Linux trace tools to view and analyze real-timescheduling 

Created by 				ASU ID			Contact Info
Achal Shah				 			
Shubham Nandanwankar 			1213350370		+1-480-859-5744

*/

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include "test.h"



int main(int argv, char* argc[])
{

	//Initailiazation of variables used
	FILE *fp;
	char line1[10];
	char *line1_str[2];
	int i=0,j=0,error_status;
	pthread_t threadid[num_lines];
	printf("PID is %d\n",getpid());
	

	
	// Taking file descriptor of the text file in fp
	if ((fp=fopen("input.txt","r")) == NULL)
		printf("Cannot open file\n");

	// Reading the first line of the .txt file to obtain no. of tasks and execution time in global variables num_lines & exec_time respectively 
	fgets(line1, sizeof(line1), fp);
	printf("%s\n", line1);
	char * token;
	printf ("Splitting string \"%s\" into tokens:\n",line1);
	token = strtok (line1," ");
	while (token != NULL){
		printf ("%s\n",token);
		line1_str[i] = token;
		if (i==0){
			num_lines = atoi(line1_str[i]);
		}
		if (i==1){
			exec_time = atoi(line1_str[i]);
		}
			
		i++;
		token = strtok (NULL, " ");
    	}
    	printf("Numbere of lines %d and exec time %d \n", num_lines,exec_time);


	// Reading each line from the line 2 of .txt file and storing it in the array of strings
	char line[num_lines][100];
	for (i = 0; i < num_lines; i++){
		fgets(line[i], sizeof(line[i]), fp);
		printf("%s\n", line[i]);
	}

	// array to store priority of all the tasks
	int prio[num_lines];

	// Creating array of node* pointers to make a array of linked lists
	struct node *head[num_lines];

	// Linked list creation and node data initialization based on the strings stored in line[num_lines][100] and storing priorities of each node in the array prio[i]
	for (i = 0; i < num_lines; i++){

		head[i] = create(line[i]);
		prio[i] = atoi(head[i]->next->data);
		printf("Priority is %d\n",prio[i]);

	}

	//Printing the linked list
	for (i = 0; i < num_lines; i++){
		print(head[i]);
	
	}

	//call to set_priority(int*) function
	set_priority(prio);

	// detecting which kind of mutex to use PI enabled or normal
	for (j = 0; j < 10; j++){
		
		
		if(*argc[argv-1]=='p'){
			printf("PI enabled Mutex activated\n");
			pthread_mutexattr_init(&mtx_attr[j]);
			pthread_mutexattr_setprotocol(&mtx_attr[j],PTHREAD_PRIO_INHERIT);
			pthread_mutex_init(&mtx[j], &mtx_attr[j]);
		}
		else if(*argc[argv-1]=='n') 
			pthread_mutex_init(&mtx[j], NULL);
			
			
	}
	
	//Initialization of all the conditional variable used 
	if(pthread_cond_init(&cond,NULL)<0)
		printf("Cond var main error");
	if(pthread_cond_init(&ap_cond_0,NULL)<0)
		printf("Cond var ap_0 error");
	if(pthread_cond_init(&ap_cond_1,NULL)<0)
		printf("Cond var ap_1 error");

	// Mouse thread creation with attributes specified in tattr1
	error_status = pthread_create( &thread_id1, &tattr1, &mouse_click, NULL);
	if(error_status != 0){
		printf("thread create error status");
	}

	// Task creation with attributes specified in tattr[i]
	printf("Create %d threads\n", num_lines);
	for(i=0; i<num_lines; i++) {
		error_status = pthread_create(&threadid[i], &tattr[i], &threadfunc, head[i]);
		if(error_status != 0){
					printf("thread create error status \n");
				} 	
	
	}

	
	// Brodcast of the starting signal will be done after 3 seconds
	sleep(3); 
	// Termination thread creation with attributes specified in tattr2
	error_status = pthread_create( &t_thread, &tattr2 , &termination,threadid);
	// call to brodcast function
	broad_cond_var();

	//Joining the termination thread
	pthread_join(t_thread, NULL);
			
	// call to cleanup function for deallocation of dynamic memory
	for(i=0;i<num_lines;i++){
		cleanup(head[i]);
	}
	
	// closing mouse file descriptor
	close(fd);
	// closing .txt file descriptor
	fclose(fp);

	return 0;
}
