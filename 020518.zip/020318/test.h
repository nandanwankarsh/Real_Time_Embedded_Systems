/* 

Real Time Embedded Systems CSE522

Assignment 1 

Assignment Objectives:
1. To program real-time tasks on Linux environment, including periodic and aporadic tasks, event handling,	
priority inheritance, etc.
2. To use Linux trace tools to view and analyze real-timescheduling 

Created by 				ASU ID			Contact Info
Achal Shah				 			
Shubham Nandanwankar 			1213350370		+1-480-859-5744

*/


#include <stdio.h>
#include <stdlib.h>
#include <linux/input.h>
#include <fcntl.h>
#include <ctype.h>
#include <time.h>
#include <semaphore.h>
#include <sys/types.h>
#define EVENT_FILE_NAME "/dev/input/event2"

//******************************************************************************************
// Variable,Objects & Structure Declarations
int num_lines;
int exec_time;

struct node{
    char *data;
    long int pthread_id_l;
    struct node *next;
};

int                 fd,conditionMet = 0, event0=0,event1=0,termination_flag,event0_count,event1_count;
pthread_t *list_tid,thread_id1,t_thread;
pthread_cond_t      cond,ap_cond_0,ap_cond_1,cond_term;
pthread_mutex_t     mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t     ap_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t     mtx[10];
pthread_mutexattr_t mtx_attr[10];

struct sched_param param[5],param1,param2;
pthread_attr_t tattr[5],tattr1,tattr2;
sem_t sem0,sem1;






// **************************************************************************************************************************************************

// Function Declarations
struct node* create(char *s); // Creates linked list for a sepcified pointer sent as a parameter
void print(struct node* head); 
void set_priority(int* prio); // Sets priority for all the tasks/threads including both mouse event and termination task/thread
void wait_cond_var(); // Makes all the tasks/threads wait for the starting condition
void broad_cond_var(); // Broadcasts start signal to all tasks/threads waiting on the condition variable cond
void *threadfunc(void *parm); // thread function which serves as starting point for both aperiodic & periodic tasks/threads
void periodic_body();// Task body for periodic thread 
void compute(int iteration);// Computation function
void aperiodic_body(struct node *head);// Task body for periodic task/thread 
void *mouse_click(); // Mouse event detection thread with static priority 95
void *termination(); // Termination thread with static priority 96
void join(); // Terminates all the waiting tasks








void set_priority(int* prio){


	param1.sched_priority = 95;
	param2.sched_priority = 96;

	int error_status2[num_lines],i,j;

	//reading priority sent from the main function for every thread
	for(i=0;i<num_lines;i++){
		printf("Priority is %d\n",*(prio+i));
		param[i].sched_priority=*(prio+i); 
	}

	// Priority set up for mouse event thread with attribute object tattr1
	pthread_attr_init(&tattr1);
	pthread_attr_setinheritsched(&tattr1,PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&tattr1, SCHED_FIFO);
	pthread_attr_setschedparam(&tattr1, &param1);

	// Priority set up for termination thread with attribute object tattr1
	pthread_attr_init(&tattr2);
	pthread_attr_setinheritsched(&tattr2,PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&tattr2,SCHED_OTHER);
	pthread_attr_setschedparam(&tattr2, &param2);

	//thread/task attribute initialization for periodic & aperiodic tasks
	for(j=0;j<num_lines;j++){
		error_status2[j] = pthread_attr_init(&tattr[j]);
		if(error_status2[j] != 0){
			printf("attr_init error %d= %d\n",j,error_status2[j]);
		}

		//thread/task scheduling attribute specification explicitly done for periodic & aperiodic tasks
		error_status2[j] = pthread_attr_setinheritsched(&tattr[j],PTHREAD_EXPLICIT_SCHED);
		if(error_status2[j] != 0){
			printf("thread %d setinherit_sched error = %d\n",j,error_status2[j]);
		}

		//thread/task scheduling policy set to FIFO for periodic & aperiodic tasks
		error_status2[j] = pthread_attr_setschedpolicy(&tattr[j],SCHED_FIFO);
		if(error_status2[j] != 0 ){
			printf("thread %d setschedpolicy error = %d\n",j,error_status2[j]);
		}

		//Static priority given for all the periodic & aperiodic tasks using the values stored in param[j]
		error_status2[j] = pthread_attr_setschedparam(&tattr[j], &param[j]);
		if(error_status2[j] != 0){
			printf("thread %d setschedparam error = %d\n", j,error_status2[j]);
		} 
	}

  

}


// Makes all the tasks/threads wait for the starting condition
void wait_cond_var(){

	// Mutex locked for conditional variable cond	
	pthread_mutex_lock(&mutex);	 
	
	// When conditionMet is false thread context will go into while loop and gets blocked
	// As soon as broadcast is done conditionMet is set and each thread waiting on cond will start executing as per the scheduler policy
	
	while (!conditionMet) {		// conditionMet is a state variable to notify brodcasting is done
		printf("Thread %ld blocked for intialization signal\n",pthread_self());
		pthread_cond_wait(&cond, &mutex);	// waiting on condition variable cond
	}

	// Mutex is unlocked for each thread context
	pthread_mutex_unlock(&mutex); 

}


// Broadcasts start signal to all tasks/threads waiting on the condition variable cond
void broad_cond_var(){

	// Mutex locked for conditional variable cond
	pthread_mutex_lock(&mutex);
	
	//conditionMet is set
	conditionMet = 1;
	printf("Wake up all waiting threads...\n");

	//Brodcast is done to all the threads/tasks waiting on the condition variable cond	
	pthread_cond_broadcast(&cond);

	// Mutex is unlocked 
	pthread_mutex_unlock(&mutex);
	printf("Wait for threads and cleanup\n");
}


// thread function which serves as starting point for both aperiodic & periodic tasks/threads
void *threadfunc(void *parm){

	//Dereferencing linked list pointer for each periodic & aperiodic tasks/threads 
	struct node *head;
	head=(struct node *)parm;
	
	// call to wait on the condition variable to make phase zero for execution
	wait_cond_var();
	head->pthread_id_l = pthread_self();

	//Task body call for aperiodic and periodic tasks/threads as stored in the linked list
	if(*(head->data)=='A')
		aperiodic_body(head);
	else
		periodic_body(head);

	pthread_exit(NULL);

}

// Task body for periodic thread 
void periodic_body(struct node *head){

	struct node* temp;

	// Object creation for nanosleep function
	struct timespec next_time,period_time;
	int iteration,mutex_no,i,period;

	//starting address given to the temporary node* pointer
	temp = head;

	//period value extraction from linked list  
	for (i = 0; i < 3; i++){
		if(i==2){
			period = atoi((temp->data));
		}
		temp = temp->next;
	}

	clock_gettime(CLOCK_MONOTONIC, &next_time);
	period_time.tv_nsec = period*1000000;


	while(termination_flag==0){

		while((temp!=NULL)){
		
		//Outer if-else loop checks for task body has Mutex or computation at current node data
		if (isalpha(*(temp->data))){
			//
			if (*(temp->data)=='L'){
				mutex_no = atoi((temp->data+1));
				printf("%c%d ",*(temp->data),mutex_no );
				pthread_mutex_lock(&mtx[mutex_no]);
			}
			else{
				mutex_no = atoi((temp->data+1));
				printf("%c%d ",*(temp->data),mutex_no );
				pthread_mutex_unlock(&mtx[mutex_no]);
			}
			temp = temp->next;// Linked list node updation 
		}
		else{//Computations are processed
			iteration = atoi(temp->data);
			printf("%d ", iteration );
			compute(iteration); //call to compute function with value specified at linked list node
			temp = temp->next;// Linked list node updation 
			}
		}

		printf("\n Task body done for %lu \n", pthread_self() );
		temp = head->next->next->next;

		// Implementing periodicity using nanosleep
		if((next_time.tv_nsec+period_time.tv_nsec)>=1000000000){
			next_time.tv_nsec = (next_time.tv_nsec+period_time.tv_nsec)%1000000000;
			next_time.tv_sec++;

		}
		else{   
			next_time.tv_nsec = next_time.tv_nsec+period_time.tv_nsec;
		}


		//If termination flag is zero then context is slept for time specified in period
		if (termination_flag==0)
		{
		clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next_time, 0);
		}

	}

	// de-allocation temp node
	free(temp);

	pthread_exit(NULL);

}

// Computation function
void compute(int iteration){
	int k, j=0;
	printf("\nIteration %d for thread %lu\n",iteration,pthread_self());
	for (k = 0; k < iteration; k++){
	 	 j = j + k;
	}

}

// Terminates all the waiting tasks
void join(){
	int i;
	printf("Inside join function");
	for (i=0; i<num_lines; i++){
		if (!(pthread_equal(*(list_tid+i),pthread_self()))){
			printf("joining thread %lu\n",*(list_tid+i));
			pthread_join(*(list_tid+i),NULL);
		}  
	}


}

// Task body for periodic task/thread 
void aperiodic_body(struct node *head){

	struct node* temp;
	printf("In aperiodic body\n");
	while(termination_flag==0){// termination flag check

		if(atoi(head->next->next->data)==0){// Left click event loop
			//Mutex lock for condition variable ap_cond_0
			pthread_mutex_lock(&ap_mutex);
			printf("Aperiodic Thread %ld blocked for event %d\n",pthread_self(),atoi(head->next->next->data));
			
			// Condition variable ap_cond_0 which makes all the aperiodic tasks which is supposed be triggered by Left click wait			
			if(pthread_cond_wait(&ap_cond_0, &ap_mutex)<0)
			printf("ap_cond_0 error\n");
			event0_count++;
			event0=0;//event0 flag reset so that executed context will bot run until next broadcast command

			//Unlocking mutex used for sondition variable ap_cond_0
			pthread_mutex_unlock(&ap_mutex);

			// Takes context outside of the while loop when termination_flag is set to 1
			if(termination_flag==1)
		      		break;
			}
			else if(atoi(head->next->next->data)==1){// Right click event loop
				//Mutex lock for condition variable ap_cond_0
				pthread_mutex_lock(&ap_mutex);
		   		printf("Aperiodic Thread %ld blocked for event %d\n",pthread_self(),atoi(head->next->next->data));
		    		
				// Condition variable ap_cond_0 which makes all the aperiodic tasks which is supposed be triggered by Right click wait
				if(pthread_cond_wait(&ap_cond_1, &ap_mutex)<0)
		  		printf("ap_cond_1 error\n");	
				
				event1_count++;
				event1=0;// event1 flag reset so that executed context will bot run until next broadcast command
				
				//Unlocking mutex used for sondition variable ap_cond_0
				pthread_mutex_unlock(&ap_mutex);
				
				// Takes context outside of the while loop when termination_flag is set to 1
				if(termination_flag==1)
				 	break;
				//	goto label;
				}


			// Taskbody implementation for mutex as well as iteration based on the value at each Linked list node similar to that of periodic thread
			if (termination_flag==0){

				printf("*****Thread %ld Executed\n",pthread_self());
				//struct node* temp;
				temp = head->next->next->next;
				int iteration,mutex_no;
				while(temp!=NULL){
					if (isalpha(*(temp->data))){
				  		if (*(temp->data)=='L'){
				      			mutex_no = atoi((temp->data+1));
				      			printf("Mutex %d locked\n",mutex_no );
				      			pthread_mutex_lock(&mtx[mutex_no]);
				  		}
				  		else{
						      	mutex_no = atoi((temp->data+1));
							printf("Mutex %d unlocked\n",mutex_no );
							pthread_mutex_unlock(&mtx[mutex_no]);
				  		}

				  		temp = temp->next; 
					}
					else{
						iteration = atoi(temp->data);
						printf("Iterations for aperiodic thread are %d\n", iteration );
						compute(iteration);
						temp = temp->next;
					}
				}

				printf("Event detected %d for thread %lu*********************************************************************************\n",atoi(head->next->next->data),pthread_self());
			}  
		}
	free(temp);
	printf("End loop\n");
	pthread_exit(NULL);

}

// Mouse event detection thread with static priority 95
void *mouse_click(){

	// Event device open and error checking
	struct input_event event;
	fd = open(EVENT_FILE_NAME, O_RDONLY);
	if (fd < 0){
		printf("failed to open input device %s: %d\n", EVENT_FILE_NAME, errno);     
	}

	while((termination_flag==0) && (read(fd,&event,sizeof(event)))){

		//In event of left or right click release broadcast is done to all the threads waiting on the condition variable cond_ap_0 & cond_ap_1 respectively
		if(event.code == 272 && event.value == 0 && conditionMet>0){
			printf("Left click event detected\n\n");
			pthread_mutex_lock(&ap_mutex);
			event0 = 1;
			printf("Wake up all left click waiting threads...\n");
			pthread_cond_broadcast(&ap_cond_0);
			pthread_mutex_unlock(&ap_mutex);
		}
		if(event.code == 273 && event.value == 0 && conditionMet >0){
			printf("Right click event detected\n\n");
			pthread_mutex_lock(&ap_mutex);
			event1 = 1;
			printf("Wake up all right click waiting threads...\n");
			pthread_cond_broadcast(&ap_cond_1);
			pthread_mutex_unlock(&ap_mutex); 
		}

	}

  

  pthread_exit(NULL);
}

void *termination(void *tid){
	
	pthread_t *t_tid=(pthread_t *)tid;
	int j;

	// Sleeping for the execution time as specified in the text file
	sleep(exec_time/1000);

	// Wakes up after exec_time/1000 second and sets termination flag to one
	printf("Termination thread woken up\n");
	termination_flag = 1;
	sleep(1);
	// Executing all the tasks in ready/eunning state after termination
	pthread_cond_broadcast(&ap_cond_0);
	pthread_cond_broadcast(&ap_cond_1);
	
	// Destroying all the condition variable and Mutex related to it
	pthread_cond_destroy(&cond); 
	pthread_cond_destroy(&ap_cond_0); 
	pthread_cond_destroy(&ap_cond_1); 
	pthread_mutex_destroy(&mutex);
	pthread_mutex_destroy(&ap_mutex);

	//Destroying all the Mutex defined for task body
	for (j = 0; j < 10; j++){
		pthread_mutex_destroy(&mtx[j]);
	}
	// all the pthread ids of waiting threads are taken in list_tid 
	list_tid=t_tid;
 
	// Terminates all the waiting tasks
	join();


	pthread_exit(NULL);

}

// Creates linked list for a sepcified pointer sent as a parameter
struct node* create(char *s)
{

	char *token;    
	token = strtok (s," "); 
	struct node *temp;
	struct node *head;
	head=NULL;
	//temp = (struct node*)malloc(sizeof(struct node));
	while(token != NULL)
	{

		if(head==NULL)
		{
			 temp=(struct node*)malloc(sizeof(struct node));
			 temp->data=token;
			 temp->next=NULL;
			 head=temp;
			 printf("%s\n", head->data);
		}
		else
		{
			temp->next=(struct node*)malloc(sizeof(struct node));
			 temp=temp->next;
			 temp->data=token;
			 printf("%s\n", temp->data);
			 temp->next=NULL;
		}
		token = strtok (NULL, " ");
	}

	printf("Creation complete\n");
	//free(temp);

	return head;
}

// Prints every linked list which represents task/thread body
void print(struct node* head)
{
	struct node *temp;
	static int i=1;
	temp = (struct node*)malloc(sizeof(struct node));
	temp=head;
	// printf("%s\n", head->data);
	while(temp!=NULL)
	{
		// printf("in while\n");
		printf("%s->",temp->data);
		temp=temp->next;
	}
	printf("Linked List %d is completed\n",i);
	i++;
	free(temp);
}
 
// Deallocation of all the dynamic memory used
void cleanup(struct node* head)
{
	struct node* tmp;

	while (head != NULL)
	{
		tmp = head;
		head = head->next;
		free(tmp);
	}

}
