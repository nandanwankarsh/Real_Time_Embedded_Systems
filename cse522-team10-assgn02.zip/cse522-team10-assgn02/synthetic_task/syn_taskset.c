#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "edf.h"
#include "RM.h"
#include "DM.h"

#define LEN 256

FILE * fp;
int M=3;// NO of folds for period calculation
float range=10;// start value of the period range
int task_len=25;// no of tasks in a taaskset..... if you want to test this program for different taskset then please change the value to either 10 or 25
int taskset_len=5000;// no of tasksets
long count=0;

void UUnifast(int n, float U, float* unifst);// Implemntation of Uunifast algorithm in line with the cited paper
void period_range(float range_period[][3]);// Period calculation for the synthetic task
// void write_file(int task_len, float syn_taskset[][3]);

int main(){

	float u=0;
	float syn_taskset[task_len][3],taskset[task_len*3];// Array and Matrix to store one synthetic task 
	int sched_task_arr[10],rm_sched_arr[10],dm_sched_arr[10];// arrays to store count of schedulable tasksets per utilization indexed 0(0.05) to 9(0.95)
	// fp = fopen ("synthetic_input.txt","w");
	// fclose (fp);
	// fp = fopen ("synthetic_input.txt","a+");
	// fprintf (fp, "%d\n",taskset_len);
	// float wcet_syn[task_len],syn_taskset[i][2][task_len],dead_syn[task_len],uti_syn[task_len];
	float array[10] = {0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95};// array to store Utilization
	for(int k=0;k<10;k++){		
		int sched_task=0,rm_sched_task=0,dm_sched_task=0;// variables to store count of schedulable task for a utilization
		printf("For Utilization %f #########################################\n",array[k]);
		for (int j = 0; j < taskset_len; j++){
			count++;
			printf("-------------------  Taskset %d -----------------\n",j);

			//float sum = 0;	

			// int i = rand()%(9 + 1 - 0) + 0;
			u = array[k];
			printf("For U == %.2f \n", u);

			float unifst[task_len];

			UUnifast(task_len,u, unifst);// function call calculates utlization and stores utilization values in array unifst[] 

			// for (int i = 0; i < task_len; i++){
				
			// 	printf("%.3f \t", unifst[i]);
			// 	sum += unifst[i];

			// }

			// uti_syn[j]=sum;
			// printf("Sum is ======= %.2f\n", sum);

			period_range(syn_taskset);// calculates and returns value of periods as per the fold and range stores it in the matrix syn_taskset's column 3
			// printf("WCET obtained is \n");
			// printf("\n");
			for(int i=0;i<task_len;i++){	//WCET calculation using utilization and period
				syn_taskset[i][0]=syn_taskset[i][2]*unifst[i];

				// printf("WCET of %d is ",i );
				 // printf("%f\t",syn_taskset[i][0]);
			}

			// printf("\n");

			for(int i=0;i<task_len;i++){// deadline calculation for two different ranges ..... if you want to use other range to evaluate please comment one and uncomment other one
				 // syn_taskset[i][1]=(fmodf((float)rand(),(syn_taskset[i][0]+((syn_taskset[i][2]-syn_taskset[i][0])/2.0)+1.0-syn_taskset[i][0]))+syn_taskset[i][0]);
				 syn_taskset[i][1]=(fmodf((float)rand(),(syn_taskset[i][2]+1.0-((syn_taskset[i][2]-syn_taskset[i][0])/2.0))+((syn_taskset[i][2]-syn_taskset[i][0])/2.0)));
				if(syn_taskset[i][1]<syn_taskset[i][0]){
					 // printf("%f\t",syn_taskset[i][1]);
					i--;
				}
				
			}
			for (int i=0;i<task_len;i++){
				for(int j=0;j<3;j++){

						// taskset[i*3+j]=taskset_mat[i][j];
						taskset[i*3+j]=syn_taskset[i][j];
					}
			}

			// printf("EDF for task %d *************************************************\n",j);
			if(edf(taskset,task_len)>0){// EDF analysis using EDF library
				sched_task++;
				printf("Task i s schedulable !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			}
			if(rm(syn_taskset,task_len)>0){// RM analysis using RM library
				rm_sched_task++;
				printf("Task is schedulable !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			}


			if(dm(syn_taskset,task_len)>0){// DM analysis using DM library
				dm_sched_task++;
				printf("Task is schedulable !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			}


			// for (int i = 0; i < task_len; i++){
			// 	// printf("Task %d ",i);
			// 	printf("        \tWCET\t\tDline\t\tPeriod\n");
			// 	printf("Task %d \t",i);
			// 	printf("\t%f\t%f\t%f\n",syn_taskset[i][0],syn_taskset[i][1],syn_taskset[i][2]);
			// }


			// write_file(task_len, syn_taskset);

			printf("\n");


			// printf("\n\n");
			}

			sched_task_arr[k]=sched_task;//Storing the calculated 
			rm_sched_arr[k]=rm_sched_task;//counts for schedulable task as per the index of utilization
			dm_sched_arr[k]=dm_sched_task;//
		}

	
	for (int i = 0; i < 10; ++i)
	{
		printf("%d\t",sched_task_arr[i]);
	}
	printf("\n");
	for (int i = 0; i < 10; ++i)
	{
		printf("%d\t",rm_sched_arr[i]);
	}
		printf("\n");

	for (int i = 0; i < 10; ++i)
	{
		printf("%d\t",dm_sched_arr[i]);
	}
		printf("\n");

	printf("Total no. of tasksets:%lu\n",count);	
	// write_file(syn_taskset);

	/* close the file*/  
   // fclose (fp);


	return 0;
}

void period_range(float range_period[][3]){

	for(int i=0;i<task_len/M;i++){
		// float random=(float)rand();
		range_period[i][2]=(fmodf((float)rand(),(pow(range,2)+1.0-pow(range,1)))+pow(range,1));		// Period calculation for the First fold
		// printf("period %d in range 1 %f\t",i,range_period[i][2]);
	}

	for(int i=task_len/M;i<task_len*2/M;i++){
		// float random=(float)rand();
		range_period[i][2]=(fmodf((float)rand(),(pow(range,3)+1.0-pow(range,2)))+pow(range,2));		// Period calculation for the Second fold
		// printf("period %d in range 2 %f\t",i,range_period[i][2]);
	}

	for(int i=task_len*2/M;i<(task_len);i++){
		// float random=(float)rand();
		range_period[i][2]=(fmodf((float)rand(),(pow(range,4)+1.0-pow(range,3)))+pow(range,3));		// Period calculation for the Third fold
		// printf("period %d in range 3%f\t",i,range_period[i][2]);
	}

}

void UUnifast(int n,float U, float* unifst){

float sumU = U,nextSumU=0,vectU=0;
// float vect_array[n];
for (int i = 0; i < (n-1); i++){

	int a = rand()%(100 + 1 - 10) + 10;
 	nextSumU = sumU*pow((a/100.0),(1.0/( n - i)));
 	vectU = sumU - nextSumU;
 	if (vectU <= 0.000){
 		i--;
 	//	printf("Test Test  \n");
 	}
 	else{
 		unifst[i] = vectU;
	 	sumU = nextSumU;	
	}
} 

unifst[n-1] = sumU;

 return;

}

// void write_file(int task_len, float syn_taskset[][3]){
//    int i;

//    fprintf (fp, "%d\n",task_len);

//    for (int i = 0; i < task_len; i++){
			
//    		fprintf (fp, "%f %f %f\n",syn_taskset[i][0],syn_taskset[i][1],syn_taskset[i][2]);

// 		}
 
//    return ;
// }
