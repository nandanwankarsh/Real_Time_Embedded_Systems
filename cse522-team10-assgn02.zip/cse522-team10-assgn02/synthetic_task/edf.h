#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <math.h>


int check_utilization(int num_tasks, float* taskset); //calculates utilization of the taskset given as parameter
double busy_period(int num_tasks, float* taskset);	// Calculates busy period for the case deadline < period
int edf(float* taskset,int no_tasks);	// Performs edf analysis calls different functions based on the deadline and period cases
void calculate_proc_demand(float table[][3],float taskset_ref[],float busy_val,int num_lines,int count_unq);// Calculates processor demdand in the case of deadline<period for Loading factor calculation
void merge(float arr[], int l, int m, int r);// Merge sort function
void mergeSort(float arr[], int l, int r);// merge sort function
int removeDuplicates(float a[], int array_size);// function for removing duplicates from an array

float uti_value;




int edf(float taskset[],int no_tasks){
	long sched=0,non_sched=0; 
	int count=0;   
	
	printf("\n");
	for (int i = 0; i < (3*no_tasks); i = i+3){

		if(taskset[i+1] == taskset[i+2]){

			count++;	//Counting the number of tasks whose period = deadline
		}
	}

	if (count == no_tasks){			//If all tasks have deadline = period do just utilization analysis

		printf("Deadline = period analysis\n");
		int u = check_utilization(no_tasks ,taskset);
		if (u == 0){
			
			 printf("Utilization is %f so schedulable after Utilization test\n", uti_value);
			sched=1;
			non_sched=0;

		}
		else{
			  printf("Utilization is %f so not schedulable\n", uti_value);
			non_sched=1;
			sched=0;
		}

	}
	else{							// If the dealine < period first try utilization bound and if not go for busy period analysis

		printf("Deadline < period analysis\n");

		int j=0,count=0;
		double t=0;
		int u = check_utilization(no_tasks ,taskset);
		if (u == 0){				// return value = 0 ----> utilization less than 1
			
			 printf("Utilization %f so schedulable after Utilization test\n", uti_value);
			sched=1;
			non_sched=0;
		}
		else{
			 printf("Utilization %f so need to do loading factor analysis\n", uti_value);

			double L = busy_period(no_tasks ,taskset);			// Calculating the busy period

			  printf("The busy_period is %lf \n", L);        

			while(t < L){
				for (int i = 0 ; i < (3*no_tasks); i = i+3){



					if(t >= L)
						break;
					else{
						t = taskset[i+1] + j*taskset[i+2];
						   
						count ++;				// counting dealines to check for the processor demands
					}
				}

				j++;
			} 
			
			float t_array[count-1];
			j=count=t=0;


			while(t < L){
				for (int i = 0; i < (3*no_tasks); i = i+3){
					

					if(t >= L)
						break;
					else{
						t= taskset[i+1] + j*taskset[i+2];			// Getting Dealines to check for the processor demands
						// printf("Value of t is %lf\n", t);
						
						if(t<=L){
							count ++;
							t_array[count-1]=t;
						}
					}
				}

				j++;
			} 

			mergeSort(t_array,0,count-1);			// sorting the deadlines in ascending order to make the table

			int count_unq=0;
			count_unq=removeDuplicates(t_array,count);		// removing duplicate values from the tables
			float load_mat[count_unq][3];

			for(int i=0;i<=count_unq;i++){

				load_mat[i][0]=t_array[i];				// Forming matrix for loading factor analysis
			}
			

			calculate_proc_demand(load_mat,taskset,t,no_tasks,count_unq);			// Calculating processor demand at each deadline instances

			printf("    t\t    |\t   h\t    |\t   u\n");

			for(int i=0;i<count_unq;i++){

				for(int j=0;j<3;j++){

					printf("%f\t",load_mat[i][j] );
				}
				printf("\n");
			}

			int k=0,l=0;

			for(int i=0;i<count_unq;i++){

				if(load_mat[i][2]>1){

					k = 1;

					if ((k==1)&&(l==0)){
						printf("\nThe first missing Deadline is %f \n", load_mat[i][0]);

						l = 1; 

					}


					non_sched=1;
					sched=0;
					
				}

			}

			 if(sched==1){

				printf("Task is Schedulable after Loading factor analysis\n");
	
			}
			else if(non_sched==1){
				printf("Task is Non Schedulable after loading factor analysis\n");
		
			}

		}

	}

	if(sched==1){

			return 1;
		}
		else if(non_sched==1){

			return 0;
		}
		else
			return 1;

}
int removeDuplicates(float a[], int array_size)
 {
   int i, j;
 
   j = 0;
 
   // Print old array...
 // ? printf("\n\nOLD : ");
   // for(i = 0; i < array_size; i++)
   // {
   //    printf("%f ", a[i]);
   // }
 
   // Remove the duplicates ...
   for (i = 1; i < array_size; i++)
   {
     if (a[i] != a[j])
     {
       j++;
       a[j] = a[i]; // Move it to the front
     }
   }
 
   // The new array size..
   array_size = (j + 1);
 
   // Print new array...
   // printf("\nNEW : ");
   // for(i = 0; i< array_size; i++)
   // {
   //    printf("[%f] ", a[i]);
   // }
   // printf("\n\n");
 
   // Return the new size...
   return(j + 1);
 }


void calculate_proc_demand(float table[][3],float taskset_ref[],float busy_val,int num_lines,int count_unq){

	float sum_dead;
	int index=0;
	// printf("Busy Val is %f\n", busy_val);
	while(index<count_unq && table[index][0]<=busy_val){			// Calculating processor demand till the busy period

		for(int i=0;i<num_lines;i++){

			if(taskset_ref[3*i+1]<=table[index][0]){

				sum_dead+=taskset_ref[3*i];
				taskset_ref[3*i+1]=taskset_ref[3*i+1]+taskset_ref[3*i+2]	;			
			}
		}

		table[index][1]=sum_dead;
		table[index][2]=table[index][1]/table[index][0];
		// printf("Index is %f\t%f\n", table[index][0],table[index][1]);
		// printf("Index is %f\t %d\n", sum_dead,index);
		if (table[index][0]>busy_val)
			break;
		index++;

	}
	 


}



double busy_period(int num_tasks, float* taskset){

	double prev_L=0, L=0;

	for (int i = 0; i < 3*(num_tasks); i = i+3){
		
		prev_L += taskset[i];
	}
	// printf("prev_L is %d \n",prev_L );
	
	while(1){

		for (int i = 0; i < 3*(num_tasks); i = i+3){
			
			L += (ceil(prev_L/taskset[i+2]))*taskset[i];
			
		}
		// printf("L is %d \n",L );
		if(prev_L == L){
			break;
		}
		else{

			prev_L = L;
			L = 0;
		}
	}

	return L;
}

int check_utilization(int num_tasks, float* taskset){

	float u;
	int ret;
	for (int i = 0; i < (3*num_tasks); i = i+3){
		u += (taskset[i]/taskset[i+1]);
	}
	uti_value = u;			 // Storing the utilaztion value in global variable to print it later
	if (u <= 1){
		ret = 0;
	}
	else{
		ret = 1;
	}

	return ret;
}


//merge sort Reference : Geeks for Geeks
void merge(float arr[], int l, int m, int r)
{
    int i, j, k;
    int n1 = m - l + 1;
    int n2 =  r - m;
 
    /* create temp arrays */
    int L[n1], R[n2];
 
    /* Copy data to temp arrays L[] and R[] */
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1+ j];
 
    /* Merge the temp arrays back into arr[l..r]*/
    i = 0; // Initial index of first subarray
    j = 0; // Initial index of second subarray
    k = l; // Initial index of merged subarray
    while (i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
 
    /* Copy the remaining elements of L[], if there
       are any */
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }
 
    /* Copy the remaining elements of R[], if there
       are any */
    while (j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }
}
 
/* l is for left index and r is right index of the
   sub-array of arr to be sorted */
void mergeSort(float arr[], int l, int r)
{
    if (l < r)
    {
        // Same as (l+r)/2, but avoids overflow for
        // large l and h
        int m = l+(r-l)/2;
 
        // Sort first and second halves
        mergeSort(arr, l, m);
        mergeSort(arr, m+1, r);
 
        merge(arr, l, m, r);
    }
}

