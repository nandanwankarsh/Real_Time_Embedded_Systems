#include <device.h>
#include <zephyr.h>
#include <gpio.h>
#include <board.h>
#include <misc/util.h>
#include <misc/printk.h>
#include <stdio.h>
#include <stdlib.h>
#include <shell/shell.h>
#include <pinmux.h>
#include <flash.h>
#include <kernel.h>
#include <sensor.h>

#define STACKSIZE 500
#define EDGE (GPIO_INT_EDGE | GPIO_INT_ACTIVE_HIGH)
#define PRIORITY 5
#define MUX CONFIG_PINMUX_NAME
#define MY_SHELL_MODULE "shell_team10"


static struct gpio_callback callb;  //GPIO callback structure
struct sensor_value temp_value;  //Sensor value structure


struct hcsr_data {
	void (*function)();
};

struct device *temp_dev;       //Structures for binding devices
struct device *dev_gpio;
struct device *pinmux;

void my_config(int);           //Function for initializing GPIOs
void erase_data();		   //Function to erase EEPROM
void write_data(int);		   //Function to write in the EEPROM
void read_data(int, int);	   //Function to read from the EEPROM

int p,p1,p2; 
int READY;
struct device *dev,*fc_dev;
	int ret,i,j,num;
	u8_t cmp_data[64];
	u8_t data[64];

struct data_log {
	u32_t dist;
	u32_t timestamp;
};
struct data_log data_dist[8];

K_THREAD_STACK_DEFINE(thread_stack_area, STACKSIZE);

K_THREAD_STACK_DEFINE(thread_stack_area1, STACKSIZE);
struct k_thread thread_data, thread_data1;

static int shell_cmd_params_0(int argc, char *argv[])              // shell module command function
{
    //int count;
    //cmd=argv[0];                                                // getting how many values to print
    p=atoi(argv[1]);
    my_config(p);
    return 0;
}


void thread1(void* a ,void* b,void* c)	//Higher priority thread to measure distance and writing it in buffer struct data_log(8 Byte) 
{
	int i;
	int r;
	// k_mutex_lock(&my_mutex, K_FOREVER);
	u32_t start=k_cycle_get_32();	// measure start time stamp
	// struct data_
	printk("\n In the thread for reading....");
	for(i=0;i<p;i++) {
		READY=0;
		for(j=0;j<8;j++)
		{	
		
		
			r = sensor_sample_fetch(temp_dev);			// hcsr04 driver system call to trigger HCSR04
			if (r) {
				printf("error: sensor_sample_fetch failed return: %d\n", r);
				break;
			}

			//k_sleep(1);
			r = sensor_channel_get(temp_dev, SENSOR_CHAN_ALL,	//hcsr04 driver system call to get distance
					       &temp_value);
			if (r) {
				printf("error: sensor_channel_get failed return: %d\n", r);
				break;
			}
			READY=1;
			data_dist[j].dist=temp_value.val1;			//writing buffer with distance data
			data_dist[j].timestamp=temp_value.val2-start;
		}

		// printk("\n%u,%u\n",(unsigned int)data_dist[j].dist,(unsigned int)data_dist[j].timestamp);
		// k_mutex_unlock(&my_mutex);
		k_sleep(50);
	}
	//printk("\n exiting read from thread");
	// pthread_exit();

}	

void thread2(void* a ,void* b,void* c)
{
	int i;
	// k_mutex_lock(&my_mutex, K_FOREVER);
	ret=flash_write_protection_set(fc_dev, false);
		if(ret<0)
		printk("\nerror: write protection failed\n");
	
	//k_sleep(100);

	printk("trying to writen struct with size %lu\n",sizeof(data_dist));
	printk("\n IN WRITE TO EEPROM THREAD\n");
	for(i=0;i<p;i++) {



		// for(int j=0;j<8;j++){

		//write them to the FRAM 
		ret = flash_write(fc_dev, 0x00+(i*64), data_dist,sizeof(data_dist));
		if (ret<0) 
		{
			printk("error:writing to FC256 error code (%d)\n", ret);
			//return 0;
		} 
		else 
		{
			printk("Wrote %zu bytes to address 0x00.\n", sizeof(data_dist));
		}
		// k_mutex_unlock(&my_mutex);
		k_sleep(50);
		
	}	

	

	printk("\n EXIT WRITE TO EEPRM THREAD\n");
	

}	

static int shell_cmd_params_1(int argc, char *argv[])              // shell module command function
{
    //int count;
    //cmd=argv[0];                                                // getting how many values to print
    p=atoi(argv[1]);
    printk("\n\nNumber : %d\n", p);


	

    erase_data();
  //  write_data(p);

    return 0;
}

static int shell_cmd_params_2(int argc, char *argv[])              // shell module command function
{
    //int count;
    //cmd=argv[0];                                                // getting how many values to print
    p1=atoi(argv[1]);
    p2=atoi(argv[2]);
    printk("\n\nStart: %d\n", p1);
    printk("\n\nFinish: %d\n", p2);
    	
    read_data(p1,p2);

    return 0;
}

static struct shell_cmd commands[] = {  
    { "Enable", shell_cmd_params_0, "enables sensor using no. given as argc" },   
    { "Start", shell_cmd_params_1, "starts measuring distance and writes into EEPROM" },
    { "Dump", shell_cmd_params_2, "Reads from a inputted one page to another" },
    { NULL, NULL, NULL }
};                                                                              //structure to hold command

static void shell_init_cp(void)                                                  // init function for shell
{

    printk("Press Enter to initialise SHELL.\n\nEnter command: select to choose the module\n");

    
    SHELL_REGISTER(MY_SHELL_MODULE, commands);
}




void my_config(int n)		// function to configure sensor with both devices
{
	int flag;
	pinmux = device_get_binding(CONFIG_PINMUX_NAME);
	if(n==0)
	{
		printk(" No sensor selected\n");
	}	

	else if(n==1)
	{
		printk("SENSOR 1 selected \n");
		temp_dev = device_get_binding("HCSR0");
		if (!temp_dev) {
			printf("error: no temp device\n");
			return;
		}

		printk("temp device is %p, name is %s\n",
		       temp_dev, temp_dev->config->name);

		flag = pinmux_pin_set(pinmux,1,PINMUX_FUNC_A);
		if(flag!=0)
			printk("error:pinmux 1\n");

		flag = pinmux_pin_set(pinmux,2,PINMUX_FUNC_B);
		if(flag!=0)
			printk("error:pinmux 2\n");

			
		dev_gpio = device_get_binding("GPIO_0");
		gpio_pin_disable_callback(dev_gpio,5);
		// printk("gpio_set end\n");

		gpio_pin_configure(dev_gpio,5,(GPIO_DIR_IN|GPIO_INT|EDGE));
		
		struct hcsr_data *data = temp_dev->driver_data;
		gpio_init_callback(&callb,data->function, BIT(5));// intializing callback on the IO0
		gpio_add_callback(dev_gpio, &callb);	//binding call back with device pointer
		gpio_pin_enable_callback(dev_gpio,5);
	
		}


	else if(n==2)
	{
		printk("SENSOR 2 selected \n");
		temp_dev = device_get_binding("HCSR1");
		if (!temp_dev) {
			printf("error: no temp device\n");
			return;
		}

		printk("temp device is %p, name is %s\n",
		       temp_dev, temp_dev->config->name);

		flag = pinmux_pin_set(pinmux,1,PINMUX_FUNC_A);
		if(flag!=0)
			printk("error:pinmux 1\n");

		flag = pinmux_pin_set(pinmux,2,PINMUX_FUNC_B);
		if(flag!=0)
			printk("error:pinmux 2 \n");

			
		dev_gpio = device_get_binding("GPIO_0");
		gpio_pin_disable_callback(dev_gpio,5);
		// printk("gpio_set end\n");

		gpio_pin_configure(dev_gpio,5,(GPIO_DIR_IN|GPIO_INT|EDGE));
		
		struct hcsr_data *data = temp_dev->driver_data;
		gpio_init_callback(&callb,data->function, BIT(5));// intializing callback on the IO0
		gpio_add_callback(dev_gpio, &callb);	//binding call back with device pointer
		gpio_pin_enable_callback(dev_gpio,5);
	}		


	else
	{
		printk("wrong input\n");
	}	
}

void erase_data()		// Function to earse the pages in EEPROM
{
		printk("\n\nErase data");
	
		k_sleep(100);
		//printk("\nInside for loop \n");
		struct data_log clear;
		clear.dist=0;
		clear.timestamp=0;
		ret=flash_write_protection_set(fc_dev, false);	// System call to FC256 kernel API to set Protection bit
		if(ret<0)
		printk("error: write protection\n");
		k_sleep(100);
		//printk("trying to erase\n");

		ret = flash_erase(fc_dev,0x00,sizeof(clear));	// System call to FC256 kernel API to erase all 512 pages

		if (ret) 
		{
			printk("error:erasing from FC256(%d)\n", ret);
			//return 0;
		} 

		else 
		{
			printk("Erased all pages\n");

		}
	k_sleep(10);

	 k_tid_t thread_tid = k_thread_create(&thread_data, thread_stack_area,		// thread1 creation
                                 K_THREAD_STACK_SIZEOF(thread_stack_area),
                                 thread1,
                                 NULL, NULL, NULL,
                                 PRIORITY, 5, K_NO_WAIT);
	printk("\n thread ID %d",(int)thread_tid); 

	k_tid_t thread_tid1 = k_thread_create(&thread_data1, thread_stack_area1,	// thread2 creation
                                 K_THREAD_STACK_SIZEOF(thread_stack_area1),
                                 thread2,
                                 NULL, NULL, NULL,
                                 PRIORITY, 7, K_NO_WAIT);
 	printk("\n thread ID %d",(int)thread_tid1); 

// 	k_sleep(500);


 }
  
   void write_data(int num)
   {   
		
       ret=flash_write_protection_set(fc_dev, false);
		if(ret<0)
		printk("\nError in write protection");
		k_sleep(100);

		printk("trying to write\n");


    for(j=0;j<num;j++)
    {   //int count=j;
		//k_sleep(100);
		printk("Inside for loop \n");
		
		

		for (int i = 0; i < sizeof(cmp_data); i++) 
		{
			cmp_data[i] = k_cycle_get_32() & 0XFF;
			data[i] = 0x00;
		}

		/* write them to the FRAM */
		ret = flash_write(fc_dev, 0x00+(j*64), cmp_data,sizeof(cmp_data));	// API call to write function of FC256 driver
		if (ret) 
		{
			printk("Error writing to FC256! error code (%d)\n", ret);
			//return 0;
		} 

		else 
		{
			printk("Wrote %zu bytes to address 0x00.\n", sizeof(cmp_data));
		}

    }
}

void read_data(int a1,int a2)
{
	  
		struct data_log read_data[8];
	  	ret=flash_write_protection_set(fc_dev, true);
		if(ret<0)
			printk("\nError in write protection");
			k_sleep(500);

			printk("\n Before reading data \n ");

			for (i = 0; i < sizeof(data_dist)/8; i++) {
		// uncomment below if you want to see all the bytes 
		 printk("%u,%u\t", data_dist[i].dist,data_dist[i].timestamp); 
	    }
        
 for(j=a1;j<=a2;j++)
       {

		ret = flash_read(fc_dev, 0x00+(j*64),read_data,sizeof(data_dist));	// API call to read function of FC256 driver
		if (ret) 
		{
			printk("Error reading from FC256! error code (%d)\n", ret);
			//return 0;
		} 

		else 
		{
			printk("Read %zu bytes from address 0x00.\n", sizeof(read_data));
		}

		for (i = 0; i < sizeof(read_data)/8; i++) {
		// uncomment below if you want to see all the bytes 
		 printk("%u,%u\t", read_data[i].dist,read_data[i].timestamp); 
	    }
		}
}

int main()
{
	
	printk("in main\n");
	pinmux = device_get_binding(MUX);	// binding pinmux driver
	// k_mutex_init(&my_mutex);
    if(pinmux==NULL)
     	printk("Error in pinmux\n");
	
	pinmux_pin_set(pinmux, 18, PINMUX_FUNC_C);	// SDA & SCL initialization
	pinmux_pin_set(pinmux, 19, PINMUX_FUNC_C);	//

	printk("exp2 bind\n");
	dev = device_get_binding("EXP2");	// GPIO configuration for pull up 
	if(dev==NULL)
     	printk("Error in EXP2\n");
	ret=gpio_pin_write(dev,9,1);
    if(ret<0)
           printk("\nError in pin write of EXP2");
    ret=gpio_pin_write(dev,11,1);
      if(ret<0)
           printk("\nError in pin write of EXP2");

       printk("fc256 bind\n");

    fc_dev = device_get_binding("FC256_NAME");	// EEPROM device binding 
    if(fc_dev==NULL)
    	printk("fc256 driver not found\n");

            shell_init_cp();

          // int flash_erase(fc_dev, off_t offset, size_t size);
  return 0;
}